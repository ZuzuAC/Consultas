<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Países con Deuda Externa Superior al 100% de su PIB en 2020</title>
    <!-- Estilos de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Consultas</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="ejercio1.php">Ejercicio 1</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ejercio2.php">Ejercicio 2</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ejercio3.php">Ejercicio 3</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ejercio4.php">Ejercicio 4</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <h1 class="mt-5 mb-4">Países con Deuda Externa Superior al 100% de su PIB en 2020</h1>
        <?php
        // Incluir archivo de conexión
        include 'conexion.php';

        // Consulta SQL
        $sql = "SELECT Paises, Deuda_PIB
        FROM paises
        WHERE Fecha = 2020 AND Deuda_PIB >= 100
        ORDER BY Deuda_PIB DESC
        LIMIT 5;";

        $result = $conn->query($sql);

        // Comprobar si hay resultados
        if ($result->num_rows > 0) {
            echo "<div class='table-responsive'>";
            echo "<table class='table table-striped table-bordered'>";
            echo "<thead class='thead-dark'><tr><th>País</th><th>Deuda PIB (%)</th></tr></thead><tbody>";

            // Salida de datos de cada fila
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["Paises"] . "</td><td>" . $row["Deuda_PIB"] . "</td></tr>";
            }
            echo "</tbody></table>";
            echo "</div>";
        } else {
            echo "<div class='alert alert-warning' role='alert'>No hay países con deuda externa superior al 100% de su PIB en 2020.</div>";
        }

        // Cerrar conexión
        $conn->close();
        ?>
    </div>
</body>
</html>
